﻿
namespace Vidly.Models
{
    public static class RoleName
    {
        public const string CanManageMovies = "CanManageMovies";
    }
}